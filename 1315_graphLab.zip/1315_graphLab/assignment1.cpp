#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int inf = 1e9 + 9;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int c, s, q;
    int Case = 1;
    bool first = true;
    while (true) {
        cin >> c >> s >> q;
        int ans[c+1][c+1];
        if(!c and !s and !q) break;
        if (first) first = false;
        else cout << '\n';
        cout << "Case #" << Case++ << '\n';

        for (int i = 0; i < c+1; i++)
            for (int j = 0; j < c+1; j++)
                ans[i][j] = inf;

        for (int i = 1; i <= s; i++) {
            int u, v, w;
            cin >> u >> v >> w;
            ans[u][v] = w;
            ans[v][u] = w;
        }
       
        for (int k = 1; k <= c; k++)
            for (int i = 1; i <= c; i++)
                for (int j = 1; j <= c; j++)
                    ans[i][j] = min(ans[i][j], max(ans[i][k], ans[k][j]));

        for (int i = 1; i <= q; i++) {
            int u, v;
            cin >> u >> v;
            if (ans[u][v] == inf)
                cout << "no path" << '\n';
            else
                cout << ans[u][v] << '\n';
        }
    }
    return 0;
}