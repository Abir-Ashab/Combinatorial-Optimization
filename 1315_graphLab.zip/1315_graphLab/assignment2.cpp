#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF = 1e9 + 9;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int E[100 + 1][100 + 1];
    bool V[100];
    int a, b, c = 1;
    while (true)
    {
        cin >> a >> b;
        if(!(a or b)) break;
        cout << "Case " << c++ <<  ": average length between pages = "; 
        int count = 0, sum = 0;
        for (int i = 0; i <= 100; i++)
            for (int j = 0; j <= 100; j++)
                E[i][j] = INF;

        E[a][b] = 1;

        while (true) {
            cin >> a >> b;
            if(!(a or b)) break;
            E[a][b] = 1, V[a] = V[b] = true;
        }
        //floyd
        for (int k = 1; k <= 100; k++)
            for (int i = 1; i <= 100; i++)
                for (int j = 1; j <= 100; j++)
                    E[i][j] = min(E[i][j], E[i][k] + E[k][j]);

        for (int i = 1; i <= 100; i++)
            for (int j = 1; j <= 100; j++)
                if (i != j && E[i][j] != INF)
                    sum += E[i][j], count++;

        cout << setprecision(4) << ((double)sum / count)  << " clicks\n";
    }
    return 0;
}